package com.example.jobportal.service;

import com.example.jobportal.model.Application;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailNotificationService {

    private static final Logger log = LoggerFactory.getLogger(EmailNotificationService.class);

    private final JavaMailSender mailSender;
    private final String mailFrom;

    public EmailNotificationService(JavaMailSender mailSender,
                                    @Value("${spring.mail.username:}") String mailFrom) {
        this.mailSender = mailSender;
        this.mailFrom = mailFrom;
    }

    public void sendStatusUpdateEmail(Application application, String newStatus) {
        if (application.getStudent() == null || application.getStudent().getEmail() == null
                || application.getStudent().getEmail().isBlank()) {
            throw new IllegalStateException("Student email is required for status notifications.");
        }
        if (mailFrom == null || mailFrom.isBlank() || "your-email@example.com".equalsIgnoreCase(mailFrom)) {
            throw new IllegalStateException(
                    "SMTP sender is not configured. Set spring.mail.username and spring.mail.password.");
        }

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(mailFrom);
        message.setTo(application.getStudent().getEmail());
        message.setSubject("Job Application Status Update - " + application.getJob().getTitle());
        message.setText(buildMessageBody(application, newStatus));
        log.info("Sending status update mail for application {} to {}", application.getId(), application.getStudent().getEmail());
        mailSender.send(message);
    }

    private String buildMessageBody(Application application, String newStatus) {
        return "Hello " + application.getStudent().getFullName() + ",\n\n"
                + "Your application for \"" + application.getJob().getTitle() + "\" has been updated.\n"
                + "New status: " + newStatus + "\n\n"
                + "Regards,\n"
                + application.getJob().getEmployer().getFullName()
                + "\nNexus Jobs";
    }
}
