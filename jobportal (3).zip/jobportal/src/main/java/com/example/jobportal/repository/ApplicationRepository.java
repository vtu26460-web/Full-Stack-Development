package com.example.jobportal.repository;

import com.example.jobportal.model.Application;
import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByStudent(User student);
    List<Application> findByJob(Job job);
    List<Application> findByJobEmployer(User employer);
    long countByJobEmployer(User employer);
    long countByJobEmployerAndStatus(User employer, String status);
}
