package com.example.jobportal.controller;

import com.example.jobportal.model.Job;
import com.example.jobportal.model.User;
import com.example.jobportal.repository.JobRepository;
import com.example.jobportal.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/jobs")
public class JobController {

    private final JobRepository jobRepository;
    private final UserRepository userRepository;

    public JobController(JobRepository jobRepository, UserRepository userRepository) {
        this.jobRepository = jobRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public String listJobs(@RequestParam(required = false) String keyword, Model model) {
        List<Job> jobs;
        if (keyword != null && !keyword.isEmpty()) {
            jobs = jobRepository.findByTitleContainingIgnoreCaseOrSkillsRequiredContainingIgnoreCase(keyword, keyword);
            model.addAttribute("keyword", keyword);
        } else {
            jobs = jobRepository.findAll();
        }
        model.addAttribute("jobs", jobs);
        return "jobs";
    }

    @GetMapping("/post")
    public String postJobForm(Model model) {
        model.addAttribute("job", new Job());
        return "post_job";
    }

    @PostMapping("/post")
    public String saveJob(@ModelAttribute("job") Job job, Authentication auth) {
        User employer = userRepository.findByUsername(auth.getName()).orElseThrow();
        job.setEmployer(employer);
        jobRepository.save(job);
        return "redirect:/dashboard";
    }

    @PostMapping("/{id}/delete")
    public String deleteJob(@PathVariable Long id, Authentication auth) {
        User employer = userRepository.findByUsername(auth.getName()).orElseThrow();
        Job job = jobRepository.findById(id).orElseThrow();
        if (job.getEmployer().getId().equals(employer.getId())) {
            jobRepository.delete(job);
        }
        return "redirect:/dashboard";
    }
}
