package com.example.jobportal.model;

public enum Role {
    ADMIN, EMPLOYER, STUDENT
}
